package com.example.planahead5c;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.*;
import android.os.Bundle;
import java.lang.Number;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void updateBar(View view)
    {
        TextView hoursStudied = (TextView) findViewById(R.id.studiedNum);
        TextView hoursSleep = (TextView) findViewById(R.id.sleepNum);
        int studied = Integer.parseInt(hoursStudied.getText().toString());
        int slept = Integer.parseInt(hoursSleep.getText().toString());
        Double eff = ((studied*0.5) + (slept*0.5));
        ProgressBar efficiency = (ProgressBar) findViewById(R.id.efficiencyBar);
        efficiency.setProgress(eff.intValue());
    }

    /*public void progressBar(Number number){

        Number progress = (Number) findViewById(R.id.editText3);
    }*/
}
