package com.example.planaheadreminderevent;

import android.database.Cursor;

public class AlarmCursorAdapter {
    public AlarmCursorAdapter(MainActivity mainActivity, Object o) {
    }

    public void swapCursor(Cursor cursor) {
    }
}
