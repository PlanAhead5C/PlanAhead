package com.example.planahead5c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class viewEvents extends AppCompatActivity {

    DatabaseHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_events);
        myDb = new DatabaseHelper(this);

        ListView listView = (ListView) findViewById(R.id.listViewEvents);
        ArrayList<String> theList = new ArrayList<>();
        Cursor view = myDb.getEventContents();

        if (view.getCount() == 0){
            Toast.makeText(viewEvents.this, "The database was empty", Toast.LENGTH_LONG).show();
        }
        else{
            while(view.moveToNext()){
              //  theList.add(view.getString(1));
                int location = view.getColumnIndex("eventName");
                theList.add(view.getString(location));
                ListAdapter listAdapter = new ArrayAdapter<>(viewEvents.this,android.R.layout.simple_list_item_1,theList);
                listView.setAdapter(listAdapter);
            }
        }
    }

    public void homePage(View view){
        Intent home = new Intent(viewEvents.this, MainActivity.class);
        startActivity(home);
        finish();
    }

}
