package com.example.planahead5c;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);

        //Calling this function allows the efficiency to be displayed as soon as the app is opened.
        calculateEfficiency();
    }

    //This function opens the 'Create Event' menu.
    public void Event(View view)
    {
        Intent openCreate = new Intent(MainActivity.this, createEvent.class);
        startActivity(openCreate);
        finish();
    }
    //This function opens the 'Add Stats' menu
    public void Stats(View view){
        Intent addStats = new Intent(MainActivity.this, addStats.class);
        startActivity(addStats);
        finish();
    }
    //This function opens the 'Create Module' menu
    public void Module(View view){
        Intent addModule = new Intent(MainActivity.this, createModule.class);
        startActivity(addModule);
        finish();
    }
    //This function opens the 'View Events' menu
    public void vEvents(View view){
        Intent openView = new Intent(MainActivity.this, viewEvents.class);
        startActivity(openView);
        finish();
    }

    //This function resets the database.
    public void resetData(View view)
    {
        myDb.resetDate();
    }

    // This function shows the values of efficiency on the main page.
    public void calculateEfficiency()
    {
        try {
            ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
            efficiency.setProgress(Integer.parseInt(myDb.getEfficiency()));
            TextView progressNum = (TextView) findViewById(R.id.progressNumber);
            progressNum.setText(String.valueOf(myDb.getEfficiency()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //This ensures that even if the database is empty, the app does not crash.
            myDb.insertEfficiencyStats("0", "0", "0", "0");
        }
    }
}
