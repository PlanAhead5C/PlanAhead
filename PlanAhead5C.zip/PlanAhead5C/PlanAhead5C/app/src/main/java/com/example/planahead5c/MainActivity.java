package com.example.planahead5c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.*;
import android.view.View;
import android.widget.*;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity
{
    DatabaseHelper myDb;
    addStats myStats;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);
        myStats = new addStats();

        Button addStats = (Button) findViewById(R.id.addStatsButton);
        Button addEvents = (Button) findViewById(R.id.createEventButton);
        Button addModule = (Button) findViewById(R.id.createModuleButton);
        TextView effText = (TextView) findViewById(R.id.progressNumber);
        ProgressBar effBar = (ProgressBar) findViewById(R.id.progressBar);

        //Calling this function allows the efficiency to be displayed as soon as the app is opened.
       // calculateEfficiency();
    }

   /* public void calculateEfficiency() {

        ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
        int eff = addStats.calcula
        efficiency.setProgress(eff.intValue());
        int progress = eff.intValue();
        TextView progressNum = (TextView) findViewById(R.id.progressNumber);
        progressNum.setText(String.valueOf(progress));

      /*  TextView attendanceVal = (TextView) findViewById(R.id.attendNum);
        TextView studiedVal = (TextView) findViewById(R.id.studyNum);
        TextView sleepVal = (TextView) findViewById(R.id.sleepNum);

        attendanceVal.setText(myDb.getAttendance());
        studiedVal.setText(myDb.getStudy());
        sleepVal.setText(myDb.getSleep());
        int attendance = Integer.parseInt(attendanceVal.getText().toString());
        int study = Integer.parseInt(studiedVal.getText().toString());
        float newStudy = 0;
        if (study >= 20)
        {
            newStudy = 100;
        }
        else
        {
            newStudy = study*100;
            newStudy = (newStudy/20);
        }
        int sleep = Integer.parseInt((sleepVal.getText().toString()));
        if (sleep >= 49 && sleep <= 63)
        {
            sleep = 100;
        }
        else if ((sleep < 49 && sleep >= 35) || (sleep > 63 && sleep <= 70))
        {
            sleep = 50;
        }
        else if (sleep < 35 || sleep > 70)
        {
            sleep = 0;
        }

        Double eff = ((attendance * 0.3) + (newStudy* 0.5) + (sleep*0.2));
        ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
        efficiency.setProgress(eff.intValue());
        int progress = eff.intValue();
        TextView progressNum = (TextView) findViewById(R.id.progressNumber);
        progressNum.setText(String.valueOf(progress));
    }*/

    //This function opens the 'Create Event' menu.
    public void openCreate(View view)
    {
        Intent openCreate = new Intent(MainActivity.this, createEvent.class);
        startActivity(openCreate);
        finish();
    }
    //This function opens the 'Add Stats' menu
    public void Stats(View view){
        Intent addStats = new Intent(MainActivity.this, addStats.class);
        startActivity(addStats);
        finish();
    }
    //This function opens the 'Create Module' menu
    public void Module(View view){
        Intent addModule = new Intent(MainActivity.this, createModule.class);
        startActivity(addModule);
        finish();
    }
    //This function resets the database.
    public void resetData(View view)
    {
        myDb.resetDate();
    }
}
