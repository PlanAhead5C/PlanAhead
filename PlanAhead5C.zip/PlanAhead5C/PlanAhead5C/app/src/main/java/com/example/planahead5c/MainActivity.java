package com.example.planahead5c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.*;
import android.view.View;
import android.widget.*;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity
{
    DatabaseHelper myDb;
    addStats myStats;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);
        //myStats = new addStats();

        Button addStats = (Button) findViewById(R.id.addStatsButton);
        Button addEvents = (Button) findViewById(R.id.createEventButton);
        Button addModule = (Button) findViewById(R.id.createModuleButton);
        TextView effText = (TextView) findViewById(R.id.progressNumber);
        ProgressBar effBar = (ProgressBar) findViewById(R.id.progressBar);

        //Calling this function allows the efficiency to be displayed as soon as the app is opened.
        calculateEfficiency();
    }

    //This function opens the 'Create Event' menu.
    public void openCreate(View view)
    {
        Intent openCreate = new Intent(MainActivity.this, createEvent.class);
        startActivity(openCreate);
        finish();
    }
    //This function opens the 'Add Stats' menu
    public void Stats(View view){
        Intent addStats = new Intent(MainActivity.this, addStats.class);
        startActivity(addStats);
        finish();
    }
    //This function opens the 'Create Module' menu
    public void Module(View view){
        Intent addModule = new Intent(MainActivity.this, createModule.class);
        startActivity(addModule);
        finish();
    }
    //This function resets the database.
    public void resetData(View view)
    {
        myDb.resetDate();
    }
    // This function shows the values of efficiency on the main page.
    public void calculateEfficiency() {
        ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
        efficiency.setProgress(Integer.parseInt(myDb.getEfficiency()));
        TextView progressNum = (TextView) findViewById(R.id.progressNumber);
        progressNum.setText(String.valueOf(myDb.getEfficiency()));
    }


}
