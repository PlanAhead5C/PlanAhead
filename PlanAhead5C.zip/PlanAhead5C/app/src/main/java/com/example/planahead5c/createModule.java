package com.example.planahead5c;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class createModule extends AppCompatActivity
{
    DatabaseHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_module);
        myDb = new DatabaseHelper(this);
    }

    public void saveEvent(View view)
    {
        //Using a 'try... catch' stops the app from crashing if the user leaves a field blank.
        try {
            //This code gets all the values for the module.
            TextView moduleName = (TextView) findViewById(R.id.addModTitle);
            String name = moduleName.getText().toString();

            //This code inserts the event into the database.
            boolean isInserted = myDb.insertModuleStats(name);
            if(isInserted == true)
                Toast.makeText(createModule.this,"Data Inserted",Toast.LENGTH_LONG).show();
            else
                Toast.makeText(createModule.this,"Data not Inserted",Toast.LENGTH_LONG).show();
            Intent openMain = new Intent(createModule.this, MainActivity.class);
            startActivity(openMain);
            finish();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(createModule.this,"Missing Data",Toast.LENGTH_LONG).show();
        }
    }

    public void openHome(View view)
    {
        Intent openHome = new Intent(createModule.this, MainActivity.class);
        startActivity(openHome);
        finish();
    }
}
