package com.example.planahead5c;

import android.content.*;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class createEvent extends AppCompatActivity
{
    DatabaseHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);
        myDb = new DatabaseHelper(this);

        ArrayList modules = myDb.getModules();

        //This code creates the drop down lists for the module, frequency, and colour options.
        Spinner eventModule = (Spinner) findViewById(R.id.moduleSpinner);
        ArrayAdapter<String> modAdapter = new ArrayAdapter<String>(createEvent.this,
                android.R.layout.simple_list_item_1, modules);
        modAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventModule.setAdapter(modAdapter);

        Spinner eventFreq = (Spinner) findViewById(R.id.freqSpinner);
        ArrayAdapter<String> freqAdapter = new ArrayAdapter<String>(createEvent.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.frequencyValues));
        freqAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventFreq.setAdapter(freqAdapter);

        Spinner eventColour = (Spinner) findViewById(R.id.colourSpinner);
        ArrayAdapter<String> colourAdapter = new ArrayAdapter<String>(createEvent.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.colourValues));
        colourAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventColour.setAdapter(colourAdapter);
    }

    public void saveEvent(View view)
    {
        //Using a 'try... catch' stops the app from crashing if the user leaves a field blank.
        try {
            //This code gets all the values for the event.
            TextView eventName = (TextView) findViewById(R.id.addTitle);
            String name = eventName.getText().toString();

            TextView eventTime = (TextView) findViewById(R.id.addTime);
            int time = Integer.parseInt(eventTime.getText().toString());

            TextView eventType = (TextView) findViewById(R.id.addType);
            String type = eventType.getText().toString();

            TextView eventModule = (TextView) findViewById(R.id.addModule);
            String module = eventModule.getText().toString();

            CheckBox eventPriority = (CheckBox) findViewById(R.id.priorityBox);
            boolean priority = eventPriority.isChecked();

            TextView eventLength = (TextView) findViewById(R.id.addLength);
            int length = Integer.parseInt(eventLength.getText().toString());

            TextView eventLocation = (TextView) findViewById(R.id.addLocation);
            String location = eventLocation.getText().toString();

            TextView eventDate = (TextView) findViewById(R.id.addDate);
            String date = eventDate.getText().toString();

            Spinner eventFreq = (Spinner) findViewById(R.id.freqSpinner);
            String freq = eventFreq.getSelectedItem().toString();

            Spinner eventColour = (Spinner) findViewById(R.id.colourSpinner);
            String colour = eventColour.getSelectedItem().toString();

            //This code inserts the event into the database.
            boolean isInserted = myDb.insertEventStats(name, time, type, module, freq, colour, priority, length, location, date);
            if(isInserted == true)
                Toast.makeText(createEvent.this,"Data Inserted",Toast.LENGTH_LONG).show();
            else
                Toast.makeText(createEvent.this,"Data not Inserted",Toast.LENGTH_LONG).show();
            Intent openMain = new Intent(createEvent.this, MainActivity.class);
            startActivity(openMain);
            finish();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(createEvent.this,"Missing Data",Toast.LENGTH_LONG).show();
        }
    }

    public void openHome(View view)
    {
        Intent openHome = new Intent(createEvent.this, MainActivity.class);
        startActivity(openHome);
        finish();
    }
}