package com.example.planahead5c;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import static org.junit.Assert.*;

@RunWith(JUnit4.class)
public class MainActivityTest
{
    //This test uses valid data to test the efficiency calculation.
    @Test
    public void efficiencyValid()
    {
        int attendance = 80;
        int study = 12;
        int sleep = 55;
        int progress = calcEfficiency(attendance, study, sleep);
        assertNotEquals(-1, progress);
    }

    //This test uses invalid data to test the efficiency calculation.
    @Test
    public void efficiencyInvalid()
    {
        int attendance = 222;
        int study = 4242;
        int sleep = -12;
        int progress = calcEfficiency(attendance, study, sleep);
        assertEquals(-1, progress);
    }

    //This test uses boundary data to test the efficiency calculation.
    @Test
    public void efficiencyBoundary()
    {
        int attendance = 0;
        int study = 0;
        int sleep = 0;
        int progress = calcEfficiency(attendance, study, sleep);
        assertNotEquals(-1, progress);
    }

    //This is the efficiency code.
    public int calcEfficiency(int attendance, int study, int sleep)
    {
        try {
            float newStudy = 0;
            if (study >= 20) {
                newStudy = 100;
            } else {
                newStudy = study * 100;
                newStudy = (newStudy / 20);
            }
            if (sleep >= 49 && sleep <= 63) {
                sleep = 100;
            } else if ((sleep < 49 && sleep >= 35) || (sleep > 63 && sleep <= 70)) {
                sleep = 50;
            } else if (sleep < 35 || sleep > 70) {
                sleep = 0;
            }

            Double eff = ((attendance * 0.3) + (newStudy * 0.5) + (sleep * 0.2));
            int progress = eff.intValue();
            if (attendance > 100)
            {
                return -1;
            }
            else
            {
                return progress;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return -1;
    }
}