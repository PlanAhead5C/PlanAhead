package com.example.planahead5c;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class addStats extends AppCompatActivity {

    DatabaseHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_stats);
        myDb = new DatabaseHelper(this);

        Button homePage = (Button) findViewById(R.id.homePageButton);
        calculateEfficiency();
    }

    public void updateBar(View view)
    {
        //Using a 'try... catch' stops the app from crashing if the user leaves a field blank.
        try
        {
            //This code calculates the user's efficiency.
            TextView attendanceVal = (TextView) findViewById(R.id.attendNum);
            TextView studiedVal = (TextView) findViewById(R.id.studyNum);
            TextView sleepVal = (TextView) findViewById(R.id.sleepNum);
            int attendance = Integer.parseInt(attendanceVal.getText().toString());
            int study = Integer.parseInt(studiedVal.getText().toString());
            float newStudy = 0;
            if (study >= 20)
            {
                newStudy = 100;
            }
            else
            {
                newStudy = study*100;
                newStudy = (newStudy/20);
            }
            int sleep = Integer.parseInt((sleepVal.getText().toString()));
            if (sleep >= 49 && sleep <= 63)
            {
                sleep = 100;
            }
            else if ((sleep < 49 && sleep >= 35) || (sleep > 63 && sleep <= 70))
            {
                sleep = 50;
            }
            else if (sleep < 35 || sleep > 70)
            {
                sleep = 0;
            }

            Double eff = ((attendance * 0.3) + (newStudy* 0.5) + (sleep*0.2));
            ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
            efficiency.setProgress(eff.intValue());
            int progress = eff.intValue();
            TextView progressNum = (TextView) findViewById(R.id.progressNumber);
            progressNum.setText(String.valueOf(progress));

            //This code inserts the user's statistics into the database.
            boolean isInserted = myDb.insertEfficiencyStats(progressNum.getText().toString(),
                    attendanceVal.getText().toString(),
                    studiedVal.getText().toString(), sleepVal.getText().toString());
            if(isInserted == true)
                Toast.makeText(addStats.this,"Data Inserted",Toast.LENGTH_LONG).show();
            else
                Toast.makeText(addStats.this,"Data not Inserted",Toast.LENGTH_LONG).show();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(addStats.this,"Missing Data",Toast.LENGTH_LONG).show();
        }
    }

    public void calculateEfficiency()
    {
        try {
            TextView attendanceVal = (TextView) findViewById(R.id.attendNum);
            TextView studiedVal = (TextView) findViewById(R.id.studyNum);
            TextView sleepVal = (TextView) findViewById(R.id.sleepNum);

            attendanceVal.setText(myDb.getAttendance());
            studiedVal.setText(myDb.getStudy());
            sleepVal.setText(myDb.getSleep());

            ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
            efficiency.setProgress(Integer.parseInt(myDb.getEfficiency()));
            TextView progressNum = (TextView) findViewById(R.id.progressNumber);
            progressNum.setText(String.valueOf(myDb.getEfficiency()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //This ensures that even if the database is empty, the app does not crash.
            myDb.insertEfficiencyStats("0", "0", "0", "0");
        }
    }

    public void openHome(View view)
    {
        Intent openHome = new Intent(addStats.this, MainActivity.class);
        startActivity(openHome);
        finish();
    }
}
