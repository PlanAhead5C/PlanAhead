package com.example.planahead5c;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DatabaseHelper(this);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.openNavDrawer,
                R.string.closeNavDrawer
        );

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        //Calling this function allows the efficiency to be displayed as soon as the app is opened.
        calculateEfficiency();
    }

    //This function opens the 'Create Event' menu.
    public void Event(View view) {
        Intent openCreate = new Intent(MainActivity.this, createEvent.class);
        startActivity(openCreate);
    }
    //This function opens the 'Add Stats' menu
    public void Stats(View view) {
        Intent addStats = new Intent(MainActivity.this, addStats.class);
        startActivity(addStats);
    }
    //This function opens the 'Create Module' menu
    public void Module(View view) {
        Intent addModule = new Intent(MainActivity.this, createModule.class);
        startActivity(addModule);
    }

    //This function resets the database.
    public void resetData(View view)
    {
        myDb.resetDate();
    }

    // This function shows the values of efficiency on the main page.
    public void calculateEfficiency() {
        try {
            ProgressBar efficiency = (ProgressBar) findViewById(R.id.progressBar);
            efficiency.setProgress(Integer.parseInt(myDb.getEfficiency()));
            TextView progressNum = (TextView) findViewById(R.id.progressNumber);
            progressNum.setText(String.valueOf(myDb.getEfficiency()));
        }
        catch (Exception e) {
            e.printStackTrace();
            //This ensures that even if the database is empty, the app does not crash.
            myDb.insertEfficiencyStats("0", "0", "0", "0");
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {   }

}
